# IFTS N°18
Materia: PPI2
Proyecto: TP N°3 PPI2
Tematica: Delitos Argentina.
